# coding: utf-8

#
# Víctor Fernández Rubio
# David González Jiménez
# Carlos Llames Arribas
# Marta Pastor Puente

# Víctor Fernández Rubio, David González Jiménez, Carlos Llames Arribas y
# Marta Pastor Puente declaramos que esta solución
# es fruto exclusivamente de nuestro trabajo personal. No hemos sido
# ayudados por ninguna otra persona ni hemos obtenido la solución de
# fuentes externas, y tampoco hemos compartido nuestra solución con
# nadie. Declaramos además que no hemos realizado de manera deshonesta
# ninguna otra actividad que pueda mejorar nuestros resultados
# ni perjudicar los resultados de los demás.


from bottle import run, post
from pymongo import MongoClient
mongoclient = MongoClient()
db = mongoclient['giw']
c = db['users']

import hashlib
from passlib.hash import pbkdf2_sha256
from bottle import request, template
import random
import string
import onetimepass as otp

##############
# APARTADO 1 #
##############

#
# Explicación detallada del mecanismo escogido para el almacenamiento de
# contraseñas, explicando razonadamente por qué es seguro
#
# Hemos utilizado pbkdf2_sha256 Para mitigar los ataques de fuerza bruta se
# pueden utilizar algoritmos de ralentizado como PBKDF2 para encriptar las contraseñas
# Modificamos las rounds que vienen por defecto por un numero generado
# aleatoriamente (el tamaño soportado es desde(1, 1<<32) para que de esta forma sea
# más seguro, además añadimos una sal cuyo tamaño tambien es genrado aleatoriamente
# el tamaño soportado  es de (0, 1024)
#

#metodo auxiliar en el que le pasamos una contraseña generamos un numero random de vueltas
#y un tamaño de la salt y devolvemos la contraseña encriptada
def encriptarContrasenia(contrasenia):
    rondas = random.randint(10000, 100000)
    tamSalt = random.randint(1,1000)
    pbkdf2Personalizado = pbkdf2_sha256.using(rounds=rondas)
    pbkdf2Personalizado = pbkdf2_sha256.using(salt_size=tamSalt)
    return pbkdf2Personalizado.encrypt(contrasenia)

#pasandole una contraseña y un hash comprobamos que la contraseña es igual al hash
def comprobarContrasenia(contrasenia, hash):
    return pbkdf2_sha256.verify(contrasenia, hash)

	
#recogemos la informacion introducida por el usuario
#si las dos contraseñas introducidas no sean la misma devolveremos un error
#si el usuario ya estuviese registrado en nuestra base de datos devolveremos
#que el usuario ya existe, en caso de que todo vaya bien encriptamos la contraseña
#y creamos un diccionario Usuario con todos los datos introducidos añadimos el usuario
#a la base de datos y devolvemos la pagina web con la bienvenida
@post('/signup')
def signup():
    nickname = request.forms.get('nickname', type = str)
    name = request.forms.get('name', type = str)
    country = request.forms.get('country', type = str)
    email = request.forms.get('email', type = str)
    password = request.forms.get('password', type = str)
    password2 = request.forms.get('password2', type = str)

    if password != password2:
        return template('Error.tpl', message = "Las contraseñas no coinciden.")

    if(c.find({"_id": nickname}).count() > 0):
        return template('Error.tpl', message = "El alias de usuario ya existe.")

    contraseniaEncript = encriptarContrasenia(password)

    Usuario = {
        "_id" : nickname,
        "name" : name,
        "country" : country,
        "email" : email,
        "password" : contraseniaEncript,
        "semilla" : None # Aunque para el login normal no es necesario el uso de
        # semilla, se deja el campo para futuras implementaciones que permitan
        # añadir una semilla a una cuenta ya creada con autencicación estandar.
    }

    c.insert(Usuario)

    return template('Bienvenido_Usuario.tpl', name = nickname, email = email)

	
#recogemos el alias y la contraseña antigua y la nueva
#comprobamos si existe el usuario en la base de datos, buscandolo por el nickname
#comprobamos si la antigua contraseña que introduces coincide con la contraseña
#actual de dicho usuario, se la cambiamos por la nueva introducida y actualizamos el usuario
#en caso de error devolveremos una pagina web diciendo que el usuario o contraseña es incorrecto
@post('/change_password')
def change_password():
    nickname = request.forms.get('nickname', type = str)
    oldPass = request.forms.get('old_password', type = str)
    newPass = request.forms.get('new_password', type = str)

    busqueda = c.find_one({"_id": nickname})

    if(len(busqueda) == 0):
        return template('Error.tpl', message = "Usuario o contraseña incorrectos.")

    if not (comprobarContrasenia(oldPass, busqueda['password'])):
         return template('Error.tpl', message = "Usuario o contraseña incorrectos.")

    contraseniaEncript = encriptarContrasenia(newPass)

    c.update({"_id" : nickname}, {"$set": {"password" : contraseniaEncript}})
    return template ('Exito.tpl', message = 'la contraseña del usuario ' + nickname + ' ha sido modificada.')


#recogemos el nickname y la contraseña del usuario
#si el usuario existe pasamos a comprobar la contraseña y en caso correcto
#damos la bienvenida al usuario, en caso contrario devolvemos una web de error
@post('/login')
def login():
    nickname = request.forms.get('nickname', type = str)
    password = request.forms.get('password', type = str)

    busqueda = c.find_one({"_id": nickname})

    if(len(busqueda) == 0):
        return template('Error.tpl', message='¡Ese usuario no existe!')

    if not (comprobarContrasenia(password, busqueda['password'])):
        return template('Error.tpl', message='Usuario o contraseña incorrectos.')

    return template('Bienvenido_Usuario.tpl', name = nickname)





##############
# APARTADO 2 #
##############

#
# Explicación detallada de cómo se genera la semilla aleatoria, cómo se construye
# la URL de registro en Google Authenticator y cómo se genera el código QR
#
#primero guardamos en un string el alfabeto en base32 que consiste en las letras
#mayusculas del alfabeto ingles mas los numeros 2 3 4 5 6 7, despues con un for
#añadimos, en nuestro caso 32, de dicho elementos a un string de forma aleatoria


	
#recogemos la informacion introducida por el usuario
#si las dos contraseñas introducidas no sean la misma devolveremos un error
#si el usuario ya estuviese registrado en nuestra base de datos devolveremos
#que el usuario ya existe, en caso de que todo vaya bien encriptamos la contraseña
#y creamos un diccionario Usuario con todos los datos introducidos añadimos el usuario
#a la base de datos generamos una url con el email y la semilla, y la utilizamos para 
#generar un codigo QR el cual se mostrara en la pagina devuelta dando la bienvenida al usuario
@post('/signup_totp')
def signup_totp():
    nickname = request.forms.get('nickname', type = str)
    name = request.forms.get('name', type = str)
    country = request.forms.get('country', type = str)
    email = request.forms.get('email', type = str)
    password = request.forms.get('password', type = str)
    password2 = request.forms.get('password2', type = str)

    if password != password2:
        return template('Error.tpl', message = "Las contraseñas no coinciden.")

    if(c.find({"_id": nickname}).count() > 0):
        return template('Error.tpl', message = "El alias de usuario ya existe.")

    contraseniaEncript = encriptarContrasenia(password)


     #El alfabeto de Base32 utiliza las letras de la A a la Z y los números del 2 al 7.El 0 y el 1 se omiten debido
    #a su similitud con las letras O e I (así el "2" en realidad tiene un valor decimal de 26).
    #https://es.wikipedia.org/wiki/Base32
    alfabetoBase32 = string.ascii_uppercase + "234567"


    semilla = ""
    for i in range(32):
        semilla = semilla + str(random.choice(alfabetoBase32))



    Usuario = {
        "_id" : nickname,
        "name" : name,
        "country" : country,
        "email" : email,
        "password" : contraseniaEncript,
        "semilla" : semilla
    }

    c.insert(Usuario)

    url = "otpauth://totp/" + email + "?secret=" + semilla
    qrCode =  "https://api.qrserver.com/v1/create-qr-code/?color=66C2A5&data=" + url
    # Genera un código QR turquesa

    return template('QR_Exito.tpl', name = "cuenta creada para " + nickname, seed = "Semilla: " + semilla, QR = qrCode)


#recogemos el nickname y la contraseña del usuario
#si el usuario existe pasamos a comprobar la contraseña y comprobamos que el
#codigo introducido es el mismo que ha generado Google Authenticator 
#de ser todo correcto damos la bienvenida al usuario, en caso contrario devolvemos
#una web de error
@post('/login_totp')
def login_totp():
    nickname = request.forms.get('nickname', type = str)
    password = request.forms.get('password', type = str)
    totp = request.forms.get('totp', type = str)

    busqueda = c.find_one({"_id": nickname})

    if(len(busqueda) == 0):
        return template('Error.tpl', message = '¡Ese usuario no existe!')

    if not (comprobarContrasenia(password, busqueda['password'])):
        return template('Error.tpl', message = 'Usuario o contraseña incorrectos.')

    if not (otp.valid_totp (totp, busqueda['semilla'])):
        return template('Error.tpl', message = 'Usuario o contraseña incorrectos.')

    return template('Bienvenido_Usuario.tpl', name = nickname)

if __name__ == "__main__":
    # NO MODIFICAR LOS PARÁMETROS DE run()
    run(host='localhost',port=8080,debug=True)
