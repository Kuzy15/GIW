#!/usr/bin/python3

# -*- coding: utf-8 -*-

# GESTIÓN DE LA INFORMACIÓN EN LA WEB
# Curso 2017-2018
# Práctica: Aggregated Pipelines

# Víctor Fernández Rubio
# David González Jiménez
# Carlos Llames Arribas
# Marta Pastor Puente

# Víctor Fernández Rubio, David González Jiménez, Carlos Llames Arribas y
# Marta Pastor Puente declaramos que esta solución
# es fruto exclusivamente de nuestro trabajo personal. No hemos sido
# ayudados por ninguna otra persona ni hemos obtenido la solución de
# fuentes externas, y tampoco hemos compartido nuestra solución con
# nadie. Declaramos además que no hemos realizado de manera deshonesta
# ninguna otra actividad que pueda mejorar nuestros resultados
# ni perjudicar los resultados de los demás.

from bottle import get, run, request, template
from pymongo import MongoClient
from os import linesep
from datetime import datetime
import re

# We start the mongo client and assign the database and the collection as
# required in the assesment:
mongoclient = MongoClient()
db = mongoclient['giw']
usuarios = db['usuarios']
pedidos = db['pedidos']

# We will need to show different field for each row when a query is performed::
agg1_data = ['País', 'Número de usuarios']
agg2_data = ['Producto', 'Unidades vendidas', 'Precio unitario']
agg3_data = ['País', 'Rando de edad']
agg4_data = ['País', 'Número de líneas promedio por pedido']
agg5_data = ['País', 'Total € gastados']

# This function checks that the arguments passed by the GET call are the ones
# required for each of the different function calls:
def areArgsValid(function_call):
    args_predefinidos = ['n', 'min', 'c']
    args = dict(request.query)
    validos = []
    invalidos = []

    num_of_args = len(args)
    i = 0
    while i < num_of_args:
        keys_list = list(args.keys())
        key = keys_list[i]
        i = i + 1

        # If an argument is not any of the ones that can be provided (no matter
        # the function consulting), we automatically know that the call is wrong:
        if (key not in args_predefinidos):
            invalidos.append(key)
        else:
            validos.append(key)

    esValido = False

    # The list validos must contain the arguments that match any of the predefined
    # arguments and the total number of arguments passed must fulfill some
    # conditions depending of the function we are calling:
    if (function_call == "top_countries" and len(validos) == 1):
        esValido = validos[0] == 'n'

    elif (function_call == 'products' and len(validos) == 1):
        esValido = validos[0] == 'min'

    elif (function_call == 'age_range' and len(validos) == 1):
        esValido = validos[0] == 'min'

    elif (function_call == 'avg_lines'):
        esValido = True

    elif (function_call == 'total_country' and len(validos) == 1):
        esValido = validos[0] == 'c'

    if esValido == True:
        return True, 'OK'
    else:
        return False, 'Los argumentos pasados como parámetros son incorrectos para la función elegida.'


@get('/top_countries')
# http://localhost:8080/top_countries?n=3
def agg1():
    valido, mensaje = areArgsValid('top_countries')

    if valido:
        n = int(request.query.n)

        # Muestra los n países con más número de usuarios junto a dicho número de
        # usuarios. En caso de empate a usuarios, los países se ordenan alfabéticamente:
        cursor = usuarios.aggregate([
            {'$group': {'_id': '$pais', 'num_usuarios': {'$sum': 1}}},
            {'$sort': {'num_usuarios': -1, '_id': 1}},
            {'$limit': n}]) # El límite debe ser un número entero positivo

        results = []
        for each in cursor:
            each_user_data = []
            each_user_data.append(each['_id'])
            each_user_data.append(each['num_usuarios'])
            results.append(each_user_data)

        return template('style.tpl', count_results=str(len(results)), shown_fields=agg1_data, rows=results)

    else:
        return mensaje
        pass


@get('/products')
# http://localhost:8080/products?min=2.34
def agg2():
    valido, mensaje = areArgsValid('products')

    if valido:
        min = float(request.query.min)

        # Muestra por cada producto cuyo precio es igual o superior a min, el
        # número de unidades vendidas entre todos los pedidos junto con su precio
        # unitario:
        cursor = pedidos.aggregate([
            {'$unwind': '$lineas'},
            {'$match': {'lineas.precio': {'$gte': min}}},
            {'$group': {'_id': '$lineas.nombre', 'num_lineas': {'$sum': '$lineas.cantidad'},
                        'precio': {'$max': '$lineas.precio'}}}])

        results = []
        for each in cursor:
            each_order_data = []
            each_order_data.append(each['_id'])
            each_order_data.append(each['num_lineas'])
            each_order_data.append(each['precio'])
            results.append(each_order_data)

        return template('style.tpl', count_results=str(len(results)), shown_fields=agg2_data, rows=results)

    else:
        return mensaje
        pass


@get('/age_range')
# http://localhost:8080/age_range?min=80
def agg3():
    valido, mensaje = areArgsValid('age_range')

    if valido:
        min = float(request.query.min)

        # Muestra por cada país que tiene más de min usuarios, el rango de edades.
        # Estos resultados deben aparecer ordenados de mayor a menor rango de edades,
        # y en caso de empate, de manera alfabética por el nombre del país:
        cursor = usuarios.aggregate([
            {'$group': {'_id': '$pais', 'num_usuarios': {'$sum': 1}, 'min': {'$min': '$edad'}, 'max': {'$max': '$edad'}}},
            {'$match': {'num_usuarios': {'$gt': min}}},
            {'$project': {'rango': {'$add': ['$max', {'$multiply': ['$min', -1]}]}}}, # Para hacer la resta, multiplicamos el valor min por -1 y se lo sumamos al max
            {'$sort': {'rango': -1, '_id': 1}}])

        results = []
        for each in cursor:
            each_user_data = []
            each_user_data.append(each['_id'])
            each_user_data.append(each['rango'])
            results.append(each_user_data)

        return template('style.tpl', count_results=str(len(results)), shown_fields=agg3_data, rows=results)

    else:
        return mensaje
        pass


@get('/avg_lines')
# http://localhost:8080/avg_lines
def agg4():
    valido, mensaje = areArgsValid('avg_lines')

    if valido:
        # Muestra por cada país el número promedio de lineas que tienen los pedidos
        # realizados por usuarios de dicho país:
        cursor = usuarios.aggregate([
            {'$lookup': {'from': 'pedidos',
                         'localField': '_id',
                         'foreignField': 'cliente',
                         'as': 'pedidos'}},
            {'$unwind': '$pedidos'},
            {'$unwind': '$pedidos.lineas'},
            {'$group': {'_id': '$pais', 'count': {'$sum': 1}}}])

        results = []
        for each in cursor:
            print(each)
            each_order_data = []
            each_order_data.append(each['_id'])
            each_order_data.append(each['count'])
            results.append(each_order_data)

        return template('style.tpl', count_results=str(len(results)), shown_fields=agg4_data, rows=results)

    else:
        return mensaje
        pass

@get('/total_country')
# http://localhost:8080/total_country?c=Alemania
def agg5():
    valido, mensaje = areArgsValid('total_country')

    if valido:
        # Calcula el total de euros gastado en todos los pedidos realizados por
        # usuarios de un país pasado como argumento:
        pais = request.query.c

        cursor = usuarios.aggregate([
            {'$match': {'pais': pais}},
            {'$lookup': {'from': 'pedidos',
                         'localField': '_id',
                         'foreignField': 'cliente',
                         'as': 'pedidos'}},
            {'$unwind': '$pedidos'},
            {'$group': {'_id': '$pais', 'total': {'$sum': '$pedidos.total'}}}])

        results = []
        for each in cursor:
            each_user_data = []
            each_user_data.append(each['_id'])
            each_user_data.append(each['total'])
            results.append(each_user_data)

        return template('style.tpl', count_results=str(len(results)), shown_fields=agg5_data, rows=results)

    else:
        return mensaje
        pass


if __name__ == "__main__":
    # No cambiar host ni port ni debug
    run(host='localhost',port=8080,debug=True)
