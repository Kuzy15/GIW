# -*- coding: utf-8 -*-

#
# Víctor Fernández Rubio
# David González Jiménez
# Carlos Llames Arribas
# Marta Pastor Puente

# Víctor Fernández Rubio, David González Jiménez, Carlos Llames Arribas y
# Marta Pastor Puente declaramos que esta solución
# es fruto exclusivamente de nuestro trabajo personal. No hemos sido
# ayudados por ninguna otra persona ni hemos obtenido la solución de
# fuentes externas, y tampoco hemos compartido nuestra solución con
# nadie. Declaramos además que no hemos realizado de manera deshonesta
# ninguna otra actividad que pueda mejorar nuestros resultados
# ni perjudicar los resultados de los demás.


from bottle import run, get, request, template, response
import requests
import os
import string

# Resto de importaciones
from time import gmtime, strftime
import time

import hashlib
from passlib.hash import pbkdf2_sha256
from urllib.parse import urlencode

import random
import json

# Credenciales.
# https://developers.google.com/identity/protocols/OpenIDConnect#appsetup
# Copiar los valores adecuados.
CLIENT_ID     = "141391213305-v3iltnfi94cg030r1vd0pdoa93hbkr0i.apps.googleusercontent.com"
CLIENT_SECRET = "_RBiiAIk5YNHvKZTXbeY2uCe"
RESPONSE_TYPE = "code"
SCOPE = "openid%20email"
REDIRECT_URI  = "http://localhost:8080/token"

# Fichero de descubrimiento para obtener el 'authorization endpoint' y el
# 'token endpoint'
# https://developers.google.com/identity/protocols/OpenIDConnect#authenticatingtheuser
DISCOVERY_DOC = "https://accounts.google.com/.well-known/openid-configuration"

discovery_req = requests.get(DISCOVERY_DOC)
AUTH_ENDPOINT = discovery_req.json()['authorization_endpoint']
TOKEN_VALIDATION_ENDPOINT = discovery_req.json()['token_endpoint']

# Token validation endpoint para decodificar JWT
# https://developers.google.com/identity/protocols/OpenIDConnect#validatinganidtoken
TOKEN_INFO = "https://www.googleapis.com/oauth2/v3/tokeninfo"

Usuario = {
		'client_id' : CLIENT_ID,
		'client_secret' : CLIENT_SECRET,
		'response_type' : RESPONSE_TYPE,
		'scope' : SCOPE,
		'redirect_uri' : REDIRECT_URI,
		'state' : None
	}

def crearSemilla():
	# Create a state token to prevent request forgery.
	# Store it for later validation.
	state = hashlib.sha256(os.urandom(1024)).hexdigest()
	return state

@get('/login_google')
def login_google():
	global Usuario
	Usuario['state'] = crearSemilla()

	url = "https://accounts.google.com/o/oauth2/v2/auth?"
	url += "client_id=" + Usuario["client_id"]
	url += "&response_type=" + Usuario["response_type"]
	url += "&scope=" + Usuario["scope"]
	url += "&redirect_uri=" + Usuario["redirect_uri"]
	url += "&state=" + Usuario["state"]

	return template ("Login.tpl", URL = url);

@get('/token')
def token():
	global Usuario
	state = request.query.state
	codigo = request.query.code

	# Coge el token anti-CSRF
	state_user = Usuario['state']

	# Comprueba que el token anti-CSRF llegado de Google sea el mismo que el guardado en Usuario
	if state == state_user:
		values = {
				'code' : codigo,
				'client_id' : Usuario['client_id'],
				'client_secret' : Usuario['client_secret'],
				'redirect_uri' : Usuario['redirect_uri'],
				'grant_type' : 'authorization_code'
			}

		# Hace una petición para intercambiar el código temporal por el id_token y access_token
		enc_values = urlencode(values)
		token_req = requests.post(TOKEN_VALIDATION_ENDPOINT, params=enc_values)
		token_id = token_req.json()['id_token']

		# Petición para descifrar el id_token
		token_values = {
			'id_token': token_id
		}
		enc_token_values = urlencode(token_values)
		descifrar_token_req = requests.get(TOKEN_INFO, params=enc_token_values)

		valid = True
		if descifrar_token_req.status_code == 200:
			# "claims_supported": ["aud","email","exp"...]
			if descifrar_token_req.json()['aud'] != CLIENT_ID:
				valid = False
			if int(descifrar_token_req.json()['exp']) < int(time.time()):
				valid = False
		else:
			valid = False

		if valid:
			email = descifrar_token_req.json()['email']
			return template('Bienvenido_Usuario.tpl', email=email)
		else:
			return template('Error.tpl', message = "El token_id no ha podido ser validado.")
	else:
		return template('Error.tpl', message = "Los tokens anti-CSRF no coinciden.")

if __name__ == "__main__":
	# NO MODIFICAR LOS PARÁMETROS DE run()
	run(host='localhost',port=8080,debug=True)
