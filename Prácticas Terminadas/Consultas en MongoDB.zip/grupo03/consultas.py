# -*- coding: utf-8 -*-

# GESTIÓN DE LA INFORMACIÓN EN LA WEB
# Curso 2017-2018
# Práctica: Consultas en MongoDB

# Víctor Fernández Rubio
# David González Jiménez
# Carlos Llames Arribas
# Marta Pastor Puente

# Víctor Fernández Rubio, David González Jiménez, Carlos Llames Arribas y
# Marta Pastor Puente declaramos que esta solución
# es fruto exclusivamente de nuestro trabajo personal. No hemos sido
# ayudados por ninguna otra persona ni hemos obtenido la solución de
# fuentes externas, y tampoco hemos compartido nuestra solución con
# nadie. Declaramos además que no hemos realizado de manera deshonesta
# ninguna otra actividad que pueda mejorar nuestros resultados
# ni perjudicar los resultados de los demás.

from bottle import get, run, request, template
from pymongo import MongoClient
from os import linesep
from datetime import datetime
import re

# We start the mongo client and assign the database and the collection as
# required in the assesment:
mongoclient = MongoClient()
db = mongoclient['giw']
c = db['usuarios']

# We will need to show every field for each client when a query is performed
# except for the second exercice, when we will only need to return the username,
# email and birthdate:
all_fields_data = ['Nombre de usuario', 'e-mail', 'Página web', 'Tarjeta crédito', 'Hash de contraseña', 'Nombre', 'Apellido', 'Dirección', 'Aficiones', 'Fecha de nacimiento']
email_birthdate_data = ['_id', 'Email', 'Fecha de nacimiento']

# This function checks that the arguments passed by the GET call are the ones
# required for each of the different function calls:
def areArgsValid(function_call):
    args_predefinidos = ['name', 'surname', 'birthday', 'from', 'to', 'country', 'likes', 'limit', 'ord', 'month', 'ending', 'exp'];
    args = dict(request.query)
    validos = []
    invalidos = []

    num_of_args = len(args)
    i = 0
    while i < num_of_args:
        key = args.keys()[i]
        i = i + 1

        # If an argument is not any of the ones that can be provided (no matter
        # the function consulting), we automatically know that the call is wrong:
        if (key not in args_predefinidos):
            invalidos.append(key)
        else:
            validos.append(key)

    esValido = False

    # The list validos must contain the arguments that match any of the predefined
    # arguments and the total number of arguments passed must fulfill some
    # conditions depending of the function we are calling:
    if (function_call == 'find_users' and 0 < len(validos) <= 3):
        if len(validos) == 3:
            esValido = validos[2] == 'name' and validos[1] == 'surname' and validos[0] == 'birthday'
        elif len(validos) == 2:
            esValido = validos[1] == 'name' and validos[0] == 'surname'
            esValido = esValido or (validos[1] == 'name' and validos[0] == 'birthday')
            esValido = esValido or (validos[1] == 'surname' and validos[0] == 'birthday')
        elif len(validos) == 1:
            esValido = validos[0] == 'name'
            esValido = esValido or validos[0] == 'surname'
            esValido = esValido or validos[0] == 'birthday'

    elif (function_call == "find_email_birthdate" and len(validos) == 2):
        esValido = validos[1] == 'from' and validos[0] == 'to'

    elif (function_call == 'find_country_likes_limit_sorted' and len(validos) == 4):
        esValido = validos[0] == 'country' and validos[3] == 'likes' and validos[2] == 'limit' and validos[1] == 'ord'

    elif (function_call == 'find_birth_month' and len(validos) == 1):
        esValido = validos[0] == 'month'

    elif (function_call == 'find_likes_not_ending' and len(validos) == 1):
        esValido = validos[0] == 'ending'

    elif (function_call == 'find_leap_year' and len(validos) == 1):
        esValido = validos[0] == 'exp'

    if esValido == True:
        return True, 'OK'
    else:
        return False, 'Los argumentos pasados como parámetros son incorrectos para la función elegida.'

# This function append the results to a list for more easily showing them in the
# HTML output.
def showResults(cursor):
    all_users_rows = []

    for each in cursor:
        each_user_data = []
        each_user_data.append(each['_id'])
        each_user_data.append(each['email'])
        each_user_data.append(each['webpage'])

        each_user_credit_card_data = each['credit_card']['number'] + linesep
        each_user_credit_card_data += each['credit_card']['expire']['month'] + '/' + each['credit_card']['expire']['year']
        each_user_data.append(each_user_credit_card_data)

        each_user_data.append(each['password'])
        each_user_data.append(each['name'])
        each_user_data.append(each['surname'])

        each_user_address_data = "Calle: " + each['address']['street'] + linesep
        each_user_address_data += "Numero: " + each['address']['num'] + linesep
        each_user_address_data += "Pais: " + each['address']['country'] + linesep
        each_user_address_data += "CP: " + each['address']['zip']
        each_user_data.append(each_user_address_data)

        each_user_likes_data = ""
        for each_like in each['likes']:
            each_user_likes_data += str(each_like) + linesep
        each_user_data.append(each_user_likes_data)

        each_user_data.append(each['birthdate'])

        all_users_rows.append(each_user_data)
    return all_users_rows

@get('/find_users')
def find_users():
    # http://localhost:8080/find_users?name=Luz
    # http://localhost:8080/find_users?name=Luz&surname=Romero
    # http://localhost:8080/find_users?name=Luz&&surname=Romero&birthday=2006-08-14

    valido, mensaje = areArgsValid('find_users')

    if valido:
        name = request.query.name
        surname = request.query.surname
        birthday = request.query.birthday

        data = {}
        if name:
            data['name'] = name
        if surname:
            data['surname'] = surname
        if birthday:
            data['birthdate'] = birthday

        cursor = c.find(data)
        results = showResults(cursor)

        return template('style.tpl', count_results=str(cursor.count()), shown_fields=all_fields_data, rows=results)

    else:
        return mensaje
        pass


@get('/find_email_birthdate')
def email_birthdate():
    # http://localhost:8080/find_email_birthdate?from=1973-01-01&to=1990-12-31

    valido, mensaje = areArgsValid('find_email_birthdate')

    if valido:
        desde = request.query['from']
        hasta = request.query['to']

        cursor = c.find({'birthdate' : {'$gte' : desde, '$lte' : hasta}}, {'_id': 1, 'email': 1, 'birthdate': 1 })

        results = []
        for each in cursor:
            each_user_data = []
            each_user_data.append(each['_id'])
            each_user_data.append(each['email'])
            each_user_data.append(each['birthdate'])
            results.append(each_user_data)

        return template('style.tpl', count_results=str(cursor.count()), shown_fields=email_birthdate_data, rows=results)

    else:
        return mensaje
        pass


@get('/find_country_likes_limit_sorted')
def find_country_likes_limit_sorted():
    # http://localhost:8080/find_country_likes_limit_sorted?country=Irlanda&likes=movies,animals&limit=4&ord=asc

    valido, mensaje = areArgsValid('find_country_likes_limit_sorted')

    if valido:
        country = request.query.country
        likes = request.query.likes
        limit = request.query.limit
        order = request.query.ord

        gustos = likes.split(',')

        if order == 'asc':
            cursor = c.find({'$and': [{'address.country' : country}, {'likes' : {'$all': gustos}}]}).sort('birthdate', 1).limit(int(limit))
        else:
            cursor = c.find({'$and': [{'address.country' : country}, {'likes' : {'$all': gustos}}]}).sort('birthdate', -1).limit(int(limit))

        results = showResults(cursor)
        return template('style', count_results=str(cursor.count()), shown_fields=all_fields_data, rows=results)

    else:
        return mensaje
        pass


@get('/find_birth_month')
def find_birth_month():
    # http://localhost:8080/find_birth_month?month=abril

    valido, mensaje = areArgsValid('find_birth_month')

    if valido:
        mes = request.query.month

        if mes == "enero":
            mes = "01"
        elif mes == "febrero":
            mes = "02"
        elif mes == "marzo":
            mes = "03"
        elif mes == "abril":
            mes = "04"
        elif mes == "mayo":
            mes = "05"
        elif mes == "junio":
            mes = "06"
        elif mes == "julio":
            mes = "07"
        elif mes == "agosto":
            mes = "08"
        elif mes == "septiembre":
            mes = "09"
        elif mes == "octubre":
            mes = "10"
        elif mes == "noviembre":
            mes = "11"
        else:
            mes = "12"

        cursor = c.find({'birthdate' : {'$regex':'.*-' + mes + '-.*'}})
        results = showResults(cursor)
        return template('style', count_results=str(cursor.count()), shown_fields=all_fields_data, rows=results)

    else:
        return mensaje
        pass


@get('/find_likes_not_ending')
def find_likes_not_ending():
    # http://localhost:8080/find_likes_not_ending?ending=s

    valido, mensaje = areArgsValid('find_likes_not_ending')

    if valido:
        ending = request.query.ending
        cursor = c.find({'likes' : {'$not' : re.compile(ending + '$', re.I)}})
        results = showResults(cursor)
        return template('style', count_results=str(cursor.count()), shown_fields=all_fields_data, rows=results)

    else:
        return mensaje
        pass

# We have left the where condition code commented as we were not able to make it
# properly work. Every time we tried to launch the code via terminal or even
# with Jupyter Notebook, an error syntax appear indicating that the first open
# brace just after the function() declaration were wrong. We know for sure that
# the function properly calculates the years condition, and we are pretty sure
# that the JavaScript code is also correct and it would return the proper mongo
# rows. However, we have not been able to execute it among the rest of the code.
@get('/find_leap_year')
def find_leap_year():
    # http://localhost:8080/find_leap_year?exp=20

    valido, mensaje = areArgsValid('find_leap_year')

    if valido:
        exp = request.query.exp
        cursor = c.find({'$and': [{'credit_card.expire.year' : exp} #, {'$where':
                    #    function () {
                    #        if ("birthdate" in this) {
                    #            anio = this["birthdate"];
                    #            anio = anio.substring(0, 3);
                    #
                    #            if (parseInt(anio) % 4 == 0) {
                    #                if (parseInt(anio) % 100 != 0) {
                    #                    return true;
                    #                }
                    #                else if (parseInt(anio) % 400 == 0) {
                    #                    return true;
                    #                }
                    #            }
                    #        }
                    #        return false;
                    #    }}
                    ]})

        results = showResults(cursor)
        return template('style', count_results=str(cursor.count()), shown_fields=all_fields_data, rows=results)

    else:
        return mensaje
        pass

###################################
# NO MODIFICAR LA LLAMADA INICIAL #
###################################
if __name__ == "__main__":
    run(host='localhost',port=8080,debug=True)
